package monopooly.colocacion.tipoCasillas.propiedades;

public enum TipoMonopolio {
    marron,
    azul_claro,
    violeta,
    naranja,
    rojo,
    amarillo,
    verde,
    azul_marino,
    estacion,
    servicio,
    impuesto,
    suerte,
    caja_comunidad,
    parking,
    salida,
    carcel,
    ir_carcel
}
