package monopooly.gui.controllers.crearJugadores;

import io.datafx.controller.ViewController;

@ViewController(value = "/fxml/crearJugadores/MeterJugador.fxml")
public class MeterJugador {

}
