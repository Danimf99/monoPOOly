package monopooly.gui.controllers.crearJugadores;


import io.datafx.controller.ViewController;
import monopooly.player.Jugador;

@ViewController(value = "/fxml/crearJugadores/NuevoJugador.fxml")
public class NuevoJugadorController {
    private Jugador jugador;


}
