package monopooly.cartas;

public abstract class CajaComunidad extends Carta {
}
