package monopooly.cartas;

public abstract class Suerte extends Carta {
}
